package b_atividade11;

import java.util.LinkedHashSet;
import java.util.Set;

public class ConjuntoFrutas {
    public static void main(String[] args) {
        Set<String> frutas = new LinkedHashSet<>();
        frutas.add("Maçã");
        frutas.add("Banana");
        frutas.add("Laranja");

        frutas.add("Maçã");

        System.out.println("Conjunto de frutas: " + frutas);
    }
}
