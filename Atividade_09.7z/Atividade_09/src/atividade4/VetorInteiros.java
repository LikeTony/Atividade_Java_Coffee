package atividade4;

import java.util.Vector;

public class VetorInteiros {
    public static void main(String[] args) {
        Vector<Integer> vetor = new Vector<>();

        vetor.add(10);
        vetor.add(20);
        vetor.add(30);
        vetor.add(40);

        System.out.println("Conteúdo do vetor: " + vetor);
    }
}
