package atividade2;

import java.util.Arrays;

public class BuscaBinaria {
    public static void main(String[] args) {
        String[] frutas = {"Banana", "Maçã", "Laranja", "Manga", "Pera"};

        Arrays.sort(frutas);

        System.out.println("Array ordenado: " + Arrays.toString(frutas));

        String busca = "Laranja";
        int indice = Arrays.binarySearch(frutas, busca);

        if (indice >= 0) {
            System.out.println("Elemento \"" + busca + "\" encontrado no índice: " + indice);
        } else {
            System.out.println("Elemento \"" + busca + "\" não encontrado.");
        }
    }
}
