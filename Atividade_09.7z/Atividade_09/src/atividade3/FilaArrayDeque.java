package atividade3;

import java.util.ArrayDeque;
import java.util.Deque;

public class FilaArrayDeque {
    public static void main(String[] args) {
        Deque<String> fila = new ArrayDeque<>();

        fila.add("Primeiro");
        fila.add("Segundo");
        fila.add("Terceiro");

        String removido = fila.poll();
        System.out.println("Elemento removido: " + removido);
    }
}
