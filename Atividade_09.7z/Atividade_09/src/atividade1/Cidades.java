package atividade1;

import java.util.ArrayList;
import java.util.List;

public class Cidades {
    public static void main(String[] args) {
        List<String> cidades = new ArrayList<>();

        cidades.add("São Paulo");
        cidades.add("Rio de Janeiro");
        cidades.add("Belo Horizonte");

        for (String cidade : cidades) {
            System.out.println(cidade);
        }
    }
}

