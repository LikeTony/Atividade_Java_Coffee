package b_atividade10;

import java.util.ArrayList;
import java.util.List;

public class ListaCores {
    public static void main(String[] args) {
        List<String> cores = new ArrayList<>();
        
        cores.add("Vermelho");
        cores.add("Verde");
        cores.add("Azul");

        String corNoSegundoIndice = cores.get(1);
        System.out.println("A cor armazenada no segundo índice é: " + corNoSegundoIndice);
    }
}
