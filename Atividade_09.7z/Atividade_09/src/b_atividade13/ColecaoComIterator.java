package b_atividade13;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ColecaoComIterator {
    public static void main(String[] args) {
        List<Integer> numeros = new ArrayList<>();
        numeros.add(10);
        numeros.add(20);
        numeros.add(30);
        numeros.add(40);
        numeros.add(50);

        Iterator<Integer> iterator = numeros.iterator();
        while (iterator.hasNext()) {
            System.out.println("Número: " + iterator.next());
        }
    }
}
