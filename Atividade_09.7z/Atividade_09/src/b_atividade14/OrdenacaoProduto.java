package b_atividade14;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Produto implements Comparable<Produto> {
    private String nome;
    private double preco;

    public Produto(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    @Override
    public int compareTo(Produto outro) {
        return Double.compare(this.preco, outro.preco);
    }

    @Override
    public String toString() {
        return nome + " - R$ " + preco;
    }
}

class OrdenaPorNome implements Comparator<Produto> {
    @Override
    public int compare(Produto p1, Produto p2) {
        return p1.getNome().compareTo(p2.getNome());
    }
}

public class OrdenacaoProduto {
    public static void main(String[] args) {
        List<Produto> produtos = new ArrayList<>();
        produtos.add(new Produto("Notebook", 3000.00));
        produtos.add(new Produto("Smartphone", 1500.00));
        produtos.add(new Produto("Tablet", 1000.00));

        Collections.sort(produtos);
        System.out.println("Produtos ordenados por preço:");
        for (Produto produto : produtos) {
            System.out.println(produto);
        }

        Collections.sort(produtos, new OrdenaPorNome());
        System.out.println("\nProdutos ordenados por nome:");
        for (Produto produto : produtos) {
            System.out.println(produto);
        }
    }
}
