package atividade8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class OrdenacaoDecrescente {
    public static void main(String[] args) {
        List<String> lista = new ArrayList<>();
        lista.add("Banana");
        lista.add("Maçã");
        lista.add("Laranja");

        Collections.sort(lista, Collections.reverseOrder());

        System.out.println("Lista em ordem decrescente: " + lista);
    }
}
