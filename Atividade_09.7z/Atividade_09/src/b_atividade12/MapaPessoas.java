package b_atividade12;

import java.util.HashMap;
import java.util.Map;

public class MapaPessoas {
    public static void main(String[] args) {
        Map<String, Integer> pessoas = new HashMap<>();
        pessoas.put("João", 30);
        pessoas.put("Maria", 25);
        pessoas.put("Pedro", 40);

        int idade = pessoas.get("Maria");
        System.out.println("Idade da Maria: " + idade);
    }
}
