package atividade6;

import java.util.LinkedList;

public class ListaEncadeada {
    public static void main(String[] args) {
        LinkedList<String> lista = new LinkedList<>();

        lista.add("Primeiro");
        lista.add("Segundo");
        lista.add("Terceiro");

        lista.addFirst("Início");

        System.out.println("Conteúdo da lista: " + lista);
    }
}
