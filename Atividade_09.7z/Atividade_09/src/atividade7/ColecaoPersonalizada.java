package atividade7;

import java.util.Iterator;

class MinhaColecao implements Iterable<String> {
    private String[] elementos;
    private int tamanho;

    public MinhaColecao(int capacidade) {
        elementos = new String[capacidade];
        tamanho = 0;
    }

    public void adicionar(String elemento) {
        if (tamanho < elementos.length) {
            elementos[tamanho] = elemento;
            tamanho++;
        }
    }

    @Override
    public Iterator<String> iterator() {
        return new Iterator<String>() {
            private int indice = 0;

            @Override
            public boolean hasNext() {
                return indice < tamanho;
            }

            @Override
            public String next() {
                return elementos[indice++];
            }
        };
    }
}

public class ColecaoPersonalizada {
    public static void main(String[] args) {
        MinhaColecao colecao = new MinhaColecao(3);
        colecao.adicionar("Elemento 1");
        colecao.adicionar("Elemento 2");
        colecao.adicionar("Elemento 3");

        for (String elemento : colecao) {
            System.out.println(elemento);
        }
    }
}
